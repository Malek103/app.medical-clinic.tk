@extends('layouts.app')
@section('style')
<style>
    table {
        border:1px solid rgba(0,0,0,0.05) !important
    }
</style>
@endsection

@section('modals')
<!-- Modal -->
<div class="modal fade" id="examinationModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">{{__('lang.add')}} {{__('lang.exam')}}</h5>
            </div>
            <form action="/reservations/examinations/create" method="post">
                <div class="modal-body">
                        {{csrf_field()}}
                        <div class="form-group">
                            <label class="control-label">{{__('lang.exam')}}</label>
                            <select name="examination_id" required class="form-control">
                                @foreach($all_examinations as $item)
                                    <option value="{{$item->id}}">{{$item->name}}</option>
                                @endforeach
                            </select>
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="reservation_id" value="{{$res->id}}" />
                    <div class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> {{__('lang.cancel')}}</div>
                    <button type="submit" class="btn btn-primary">{{__('lang.save')}}</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="xrayModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">{{__('lang.add')}} {{__('lang.xray')}}</h5>
            </div>
            <form action="/reservations/xrays/create" method="post">
                <div class="modal-body">
                        {{csrf_field()}}
                        <div class="form-group">
                            <label class="control-label">{{__('lang.xray')}}</label>
                            <select name="xray_id" required class="form-control">
                                @foreach($all_xrays as $item)
                                    <option value="{{$item->id}}">{{$item->name}}</option>
                                @endforeach
                            </select>
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="reservation_id" value="{{$res->id}}" />
                    <div class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> {{__('lang.cancel')}}</div>
                    <button type="submit" class="btn btn-primary">{{__('lang.save')}}</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="medicineModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">{{__('lang.add')}} {{__('lang.medicine')}}</h5>
            </div>
            <form action="/reservations/medicines/create" method="post">
                <div class="modal-body">
                        {{csrf_field()}}
                        <div class="form-group">
                            <label class="control-label">{{__('lang.medicine')}}</label>
                            <select name="medicine_id" required class="form-control">
                                @foreach($all_medicines as $item)
                                    <option value="{{$item->id}}">{{$item->name}}</option>
                                @endforeach
                            </select>
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="reservation_id" value="{{$res->id}}" />
                    <div class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> {{__('lang.cancel')}}</div>
                    <button type="submit" class="btn btn-primary">{{__('lang.save')}}</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">{{__('lang.add')}} {{__('lang.payments')}}</h5>
            </div>
            <form action="/reservations/payments/create" method="post">
                <div class="modal-body">
                        {{csrf_field()}}
                        <div class="form-group">
                            <label class="control-label">{{__('lang.amount')}}</label>
                            <input type="number" name="value" class="form-control" required />
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="reservation_id" value="{{$res->id}}" />
                    <div class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> {{__('lang.cancel')}}</div>
                    <button type="submit" class="btn btn-primary">{{__('lang.save')}}</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('content')

<div class="layout-px-spacing">


            <div class="statbox widget box box-shadow create-widget">
                <div class="widget-header">
                    <div class="row">
                        <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                            <h4>{{__('lang.show')}} {{__('lang.reservation')}} #{{$res->id}}</h4>
                            @if($errors->any())
                                @foreach ($errors->all() as $error)
                                    <div class="alert alert-arrow-right alert-icon-right alert-light-danger form-err" role="alert">
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><svg xmlns="http://www.w3.org/2000/svg" data-dismiss="alert" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-alert-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12" y2="16"></line></svg>
                                        <strong>{{$error}}</strong>
                                    </div>
                                @endforeach
                            @endif  
                            @if(session('success'))
                                <div class="alert alert-icon-left alert-light-success form-err" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><svg xmlns="http://www.w3.org/2000/svg" data-dismiss="alert" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-alert-triangle"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12" y2="17"></line></svg>
                                    <strong>{{session('success')}}</strong>
                                </div>                            
                            @endif                             
                        </div>                                                                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-7">
                    <p class="res-label">{{__('lang.customer_data')}}</p>
                    <table id="table2" class="table table-hover non-hover" style="width:100%">
                        <thead>
                            <tr>
                                
                                
                                <th>{{__('lang.name')}}</th>
                                <th>{{__('lang.phone')}}</th>
                                <th>{{__('lang.email')}}</th>
                        

                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{{$customer->name}}</td>
                                <td>
                                    {{$customer->phone1}} /
                                    {{$customer->phone2}}

                                </td>
                                <td>
                                    {{$customer->email}}
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <p class="res-label">{{__('lang.reservation_data')}}</p>
                    <table id="table2" class="table table-hover non-hover" style="width:100%">
                        <thead>
                            <tr>
                                
                                
                                <th>{{__('lang.date')}}</th>
                                <th>{{__('lang.day')}}</th>
                                <th>{{__('lang.time')}}</th>
                                <th>{{__('lang.price')}}</th>
                                <th>{{__('lang.status')}}</th>
                        

                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{{$res->date}}</td>
                                <td>
                                    {{$res->day}}

                                </td>
                                <td>
                                    {{__("lang.from")}} {{$res->start_time}} {{__("lang.to")}} {{$res->end_time}}
                                </td>
                                <td>{{$res->price}}</td>
                                <td>
                                       @php
                                            $ui_value = "";
                                            if($res->status == "booked") {
                                                $ui_value = __('lang.booked');
                                            }else if ($res->status == "complete") {
                                                $ui_value = __('lang.completed');
                                            }else if ($res->status == "not_visited") {
                                                $ui_value = __('lang.not_visited');
                                            }else {
                                                $ui_value = __('lang.canceled');
                                            }
                                        @endphp
                                        
                                        {{$ui_value}}
                                </td>

                            </tr>
                        </tbody>
                    </table>
                                      

               


                                        <!-- Payments -->
                    <p class="res-label">{{__('lang.payments')}} <a href="#!" class="btn btn-primary data-btn" data-toggle="modal" data-target="#paymentModal">{{__('lang.add')}}</a></p>
                    @if(count($payments) > 0)
                    @php
                        $total = 0;
                    @endphp
                    <table id="table2" class="table table-hover non-hover" style="width:100%">
                        <thead>
                            <tr>
                                
                                
                                <th>-</th>
                                <th>{{__('lang.amount')}}</th>
                                <th>{{__('lang.date')}}</th>
                                <th>{{__('lang.actions')}}</th>
                    
                        

                            </tr>
                        </thead>
                        <tbody>
                            @foreach($payments as $item)
                            @php
                                $total = $total + $item->value;
                            @endphp
                            <tr>
                               <td>-</td>
                                <td>{{$item->value}}</td>
                                <td>{{$item->created_at->format('Y-m-d h:i a')}}</td>
                           
                                <td>
        
                                    <a class="btn btn-primary" href="/reservations/payments/{{$item->id}}/delete"><i class="fa fa-trash"></i></a>
                                </td>
                              
                            </tr>
                            @endforeach
                            <tr>
                                <td>{{__('lang.total')}}</td>
                                <td>{{$total}}</td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                    @else
                        <p class="data-label">{{__('lang.no_data')}}</p>
                    @endif

                    </div>
                  <div class="col-lg-5">

                    <p class="res-label">{{__('lang.medical_examinations')}} <a href="#!" class="btn btn-primary data-btn" data-toggle="modal" data-target="#examinationModal">{{__('lang.add')}}</a></p>
                    @if(count($examinations) > 0)
                    <table id="table2" class="table table-hover non-hover" style="width:100%">
                        <thead>
                            <tr>
                                
                                
                                <th>{{__('lang.name')}}</th>
                                <th>{{__('lang.results')}}</th>
                                <th>{{__('lang.actions')}}</th>
                    
                        

                            </tr>
                        </thead>
                        <tbody>
                            @foreach($examinations as $item)
                            <tr>
                                <form action="/reservations/examinations/update" method="post">
                                    {{csrf_field()}}
                                <td>{{$item->examination->name}}</td>
                                <td>
                                    <textarea name="result" class="form-control data-textarea">{{$item->result}}</textarea>
                                </td>
                                <td>
                                    <button class="btn btn-primary"><i class="fa fa-check"></i></button>
        
                                    <a class="btn btn-primary" href="/reservations/examinations/{{$item->id}}/delete"><i class="fa fa-trash"></i></a>
                                    <input type="hidden" name="id" value="{{$item->id}}" />
                                </td>
                                </form>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @else
                        <p class="data-label">{{__('lang.no_data')}}</p>
                    @endif
                                        
                                    
                    <!-- Xrays -->
                    <p class="res-label">{{__('lang.xrays')}} <a href="#!" class="btn btn-primary data-btn" data-toggle="modal" data-target="#xrayModal">{{__('lang.add')}}</a></p>
                    @if(count($xrays) > 0)
                    <table id="table2" class="table table-hover non-hover" style="width:100%">
                        <thead>
                            <tr>
                                
                                
                                <th>{{__('lang.name')}}</th>
                                <th>{{__('lang.results')}}</th>
                                <th>{{__('lang.actions')}}</th>
                    
                        

                            </tr>
                        </thead>
                        <tbody>
                            @foreach($xrays as $item)
                            <tr>
                                <form action="/reservations/xrays/update" method="post">
                                    {{csrf_field()}}
                                <td>{{$item->xray->name}}</td>
                                <td>
                                    <textarea name="result" class="form-control data-textarea">{{$item->result}}</textarea>
                                </td>
                                <td>
                                    <button class="btn btn-primary"><i class="fa fa-check"></i></button>
        
                                    <a class="btn btn-primary" href="/reservations/xrays/{{$item->id}}/delete"><i class="fa fa-trash"></i></a>
                                    <input type="hidden" name="id" value="{{$item->id}}" />
                                </td>
                                </form>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @else
                        <p class="data-label">{{__('lang.no_data')}}</p>
                    @endif

                                        
                    <!-- Medicines -->
                    <p class="res-label">{{__('lang.medicines')}} <a href="#!" class="btn btn-primary data-btn" data-toggle="modal" data-target="#medicineModal">{{__('lang.add')}}</a></p>
                    @if(count($medicines) > 0)
                    <table id="table2" class="table table-hover non-hover" style="width:100%">
                        <thead>
                            <tr>
                                
                                
                                <th>{{__('lang.name')}}</th>
                                <th>{{__('lang.instructions')}}</th>
                                <th>{{__('lang.actions')}}</th>
                    
                        

                            </tr>
                        </thead>
                        <tbody>
                            @foreach($medicines as $item)
                            <tr>
                               
                                <td>{{$item->medicine->name}}</td>
                                <td>
                                    {{$item->medicine->instructions}}
                                </td>
                                <td>
        
                                    <a class="btn btn-primary" href="/reservations/medicines/{{$item->id}}/delete"><i class="fa fa-trash"></i></a>
                                </td>
                              
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @else
                        <p class="data-label">{{__('lang.no_data')}}</p>
                    @endif


                    </div>
                </div>
            </div>
     

</div>
@endsection