@extends('layouts.app')
@section('style')
<style>
    .table-responsive {
        min-height:150px 
    }
</style>
@endsection
@section('content')
            <div class="layout-px-spacing">
                
                <div class="row layout-top-spacing ">

                
                    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                        <div class="widget-content widget-content-area br-6">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                      
                                        <h4 style="float:right">{{__('lang.calendar')}}</h4>
                                    
                                    </div>                 
                                </div>
                            </div> 
                            <br/>    
                          
      
                        
                            
                            <div class="col-lg-12">
                                <div class="calendar">
                                    <div class="month">
                                        <h1>{{$current_date}}</h1>

                                    </div>

                                    <ul class="days">
                                        @foreach($calendar as $item)
                                        <li @if($item['date'] == date('Y-m-d')) class="active" @endif>
                                            <time datetime="2022-02-01">{{$item['day']}}</time> {{$item['name']}}
                                            <div class="calendar-menu">
                                                <p>{{__('lang.reservations')}}</p>
                                                @if(count($item['reservations']) > 0)
                                                    @foreach($item['reservations'] as $res)
                                                    <a href="/reservations/{{$res->id}}/show" class="res-item">{{$res->customer->name}}</a>
                                                    @endforeach
                                                @else
                                                    <p class="no-results">{{__('lang.no_data')}}</p>
                                                @endif
                                                @if($item['date'] >= date('Y-m-d'))
                                                <a href="/reservations/create?date={{$item['date']}}" class="btn btn-primary">{{__('lang.add')}}</a>
                                                @endif
                                            </div>
                                        </li>
                                        @endforeach
                                      
                                    </ul>
                                </div>
                            </div>
                            <br/>
                            <br/>

                            <form action="/reservations/calendar" method="get">
                                {{csrf_field()}}
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label">{{__('lang.month')}}</label>
                                            <input @if(request()->get('month')) value="{{request()->get('month')}}" @endif type="month" name="month" class="form-control"/>
                                        </div>
                                    </div>

            
                                
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                        
                                            <button class="btn btn-primary mt-35">{{__('lang.show')}}</button>
                                        </div>
                                    </div>
                                </div>    
                            </form> 
                                           
                       
                        </div>
                    </div>

                </div>

            </div>
    
@endsection