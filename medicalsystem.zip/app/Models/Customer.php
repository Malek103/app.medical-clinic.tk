<?php

namespace App\Models;
 
use Illuminate\Database\Eloquent\Model;
use App\Models\Reservation;
use App\Models\Payment;

class Customer extends Model
{

    protected $table = 'customers';

    protected $fillable = [
        'name',
        'phone1',
        'phone2',
        'email',
        'gender',
        'image',
        'birthdate',
        'blood_type',
        'id_number',
        'user_id',
        'user_updated_id',
        'height',
        'marital_status',
        'job'
    ];

    public function reservations(){
        return $this->hasOne(Reservation::class);
    }

    public function payments(){
        return $this->hasOne(Payment::class);
    }
}
