<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Payment;
use App\Models\Reservation;

class Customers extends Controller
{
    public function index() {
        $data = Customer::all();
        return view("customers.index")->with(["data" => $data]);
    }

    public function create() {
        return view("customers.create");
    }

    public function store(Request $request) {
        $data = $request->all();
        if ($request->hasFile('image')) {
            $name = time() . "_customer." . $request->file('image')->getClientOriginalExtension();
            $request->file('image')->move('uploads', $name);
            $data['image'] = $name;
        }
        Customer::create($data);
        return redirect("/customers");
    }

    public function edit($id) {
        $customer = Customer::find($id);
        return view("customers.edit")->with(["item" => $customer]);
    }

    public function update(Request $request) {
        $item = Customer::find($request->id);

        $data = $request->all();
       
        if ($request->hasFile('image')) {
            $name = time() . "_customer." . $request->file('image')->getClientOriginalExtension();
            $request->file('image')->move('uploads', $name);
            $data['image'] = $name;
        }

        $item->fill($data)->save();

        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function destroy($id) {
        Customer::find($id)->delete();
        return redirect()->back();
    }

    public function show($id) {
        $customer = Customer::find($id);
        $reservations = Reservation::where("customer_id", $id)->get();
        $payments     = Payment::where("customer_id", $id)->get();
        return view("customers.show")->with(["customer" => $customer, "reservations" => $reservations, "payments"=> $payments]);
    }
}
