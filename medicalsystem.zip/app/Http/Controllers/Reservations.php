<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reservation;
use App\Models\Customer;
use App\Models\ResExam;
use App\Models\ResMedicine;
use App\Models\ResXRay;
use App\Models\MedicalExamination;
use App\Models\XRay;
use App\Models\Medicine;
use App\Models\Payment;
use App\Models\Transaction;

class Reservations extends Controller
{
    public function index() {
        $date_from = request()->get("date_from");
        $date_to   = request()->get("date_to");
        $status    = request()->get("status");
        $data = Reservation::where(function($query) use ($date_from, $date_to, $status) {
            if($date_from) {
                
                $query->where('date', ">=" , $date_from);
            }
            if($date_to) {
                $query->where('date', "<=" , $date_to);
            }
            if($status) {
                $query->where('status', $status);
            }

        })->orderBy("id","desc")->with('customer')->get();
        return view("reservations.index")->with(["data" => $data]);
    }

    public function create() {
        $customers = Customer::all();

        $dates = $this->getCurrentMonthDates();

        return view("reservations.create")->with(["customers"=> $customers, "dates" => $dates]);
    }

    public function store(Request $request) {
        $data = $request->all();
        $data['user_id'] = auth()->user()->id;
        $data['day'] = date('l', strtotime($request->date));
        $reservation=Reservation::create($data);
        return redirect("/reservations");
    }

    public function edit($id) {
        $reservation = Reservation::find($id);
        $customers = Customer::all();

        $dates = $this->getCurrentMonthDates();

        return view("reservations.edit")->with(["customers"=> $customers, "dates" => $dates, "res" => $reservation]);
    }

    public function update(Request $request) {
        $reservation = Reservation::find($request->id);
        $data = $request->all();
        $data['day'] = date('l', strtotime($request->date));
        $reservation->fill($data)->save();
        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function delete($id){
        Reservation::find($id)->delete();
        return redirect()->back();
    }

    public function show($id){
        $reservation = Reservation::find($id);
        $customer = Customer::find($reservation->customer_id);

        $examinations = ResExam::where("reservation_id", $id)->get();
        $xrays = ResXRay::where("reservation_id", $id)->get();
        $medicines = ResMedicine::where("reservation_id", $id)->get();
        $payments  = Payment::where("reservation_id", $id)->get();

        $all_examinations = MedicalExamination::all();
        $all_xrays = XRay::all();
        $all_medicines = Medicine::all();

        foreach($examinations as $item) {
            $examination = MedicalExamination::find($item->examination_id);
            $item->examination = $examination;
        }
        foreach($xrays as $item){
            $xray = Xray::find($item->xray_id);
            $item->xray = $xray;
        }
        foreach($medicines as $item){
            $medicine = Medicine::find($item->medicine_id);
            $item->medicine = $medicine;
        }
        return view("reservations.show")->with(["res" => $reservation, "customer" => $customer, "examinations" => $examinations, "medicines" => $medicines, "xrays" => $xrays, "all_examinations" => $all_examinations,"all_xrays" => $all_xrays, "all_medicines" => $all_medicines,"payments" => $payments]);

    }

    public function addExamination(Request $request) {
        $data = $request->all();
        $res  = Reservation::find($request->reservation_id);
        $data['customer_id'] = $res->customer_id;
        ResExam::create($data);
        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function updateExamination(Request $request) {
        $data = $request->all();
        $item  = ResExam::find($request->id);
        $item->fill($data)->save();
        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function deleteExamination($id) {
        ResExam::find($id)->delete();
        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function addXRay(Request $request) {
        $data = $request->all();
        $res  = Reservation::find($request->reservation_id);
        $data['customer_id'] = $res->customer_id;
        ResXRay::create($data);
        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function updateXRay(Request $request) {
        $data = $request->all();
        $item  = ResXRay::find($request->id);
        $item->fill($data)->save();
        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function deleteXRay($id) {
        ResXRay::find($id)->delete();
        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function addMedicine(Request $request) {
        $data = $request->all();
        $res  = Reservation::find($request->reservation_id);
        $data['customer_id'] = $res->customer_id;
        ResMedicine::create($data);
        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function deleteMedicine($id) {
        ResMedicine::find($id)->delete();
        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function addPayment(Request $request) {
        $data = $request->all();
        $res  = Reservation::find($request->reservation_id);
        $data['customer_id'] = $res->customer_id;
        $data['user_id'] = auth()->user()->id;
        $payment = Payment::create($data);
        $this->saveTransaction("payment",$payment->id, $payment->value);

        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function deletePayment($id) {
        Payment::find($id)->delete();
        Transaction::where([["item_id", $id],["type", "payment"]])->delete();
        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function calendar() {

        if(request()->get('month')) {
            $year  = explode("-", request()->get('month'))[0];
            $month  = explode("-", request()->get('month'))[1];
        }else {
            $year = date("Y");
            $month = date("m");
        }

        $list=array();
        
        for($d=1; $d<=31; $d++)
        {
            $time=mktime(12, 0, 0, $month, $d, $year);          
            if (date('m', $time)==$month)       
                $list[]=["date" => date('Y-m-d', $time), "day" => date('d', $time), "day_name" => date('l', $time)];
        }     

        $results = [];

        foreach($list as $key => $item) {
            $full_date = $item['date'];
            $res = Reservation::with('customer')->whereDate("date", $full_date)->get();
            $results[] = [
                "day"          => $item["day"],
                "name"         => $item["day_name"],
                "date"         => $item['date'],
                "reservations" => $res
            ];
            
 
        }  

        $current_date = date("Y M", strtotime($year . "-" . $month));

        return view("reservations.calendar")->with(["calendar" => $results, "current_date" => $current_date ]);
    }

    public function getCurrentMonthDates() {
        $list=array();
        $month = date("m");
        $year = date("Y");
        
        for($d=date('d'); $d<=31; $d++)
        {
            $time=mktime(12, 0, 0, $month, $d, $year);          
            if (date('m', $time)==$month)       
                $list[]=["date" => date('Y-m-d', $time), "day" => date('d', $time), "day_name" => date('l', $time)];
        }  

        return $list;
    }

    public function saveTransaction($type,$id,$value) {
        $tr = new Transaction;
        $tr->type = $type;
        $tr->item_id = $id;
        $tr->value   = $value;
        $tr->save();
        return true;
    }

}
