<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\XRay;

class Xrays extends Controller
{
    public function index() {
        $data = XRay::all();
        return view("xrays.index")->with(["data" => $data]);
    }

    public function create() {
        return view("xrays.create");
    }

    public function store(Request $request) {
        $data = $request->all();
        XRay::create($data);
        return redirect("/xrays");
    }

    public function edit($id) {
        $item = XRay::find($id);
        return view("xrays.edit")->with(["item" => $item]);
    }

    public function update(Request $request) {
        $item = XRay::find($request->id);

        $data = $request->all();
    
        $item->fill($data)->save();

        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function destroy($id) {
        XRay::find($id)->delete();
        return redirect()->back();
    }
}
