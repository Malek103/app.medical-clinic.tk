<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MedicalExamination;

class Examinations extends Controller
{
    public function index() {
        $data = MedicalExamination::all();
        return view("examinations.index")->with(["data" => $data]);
    }

    public function create() {
        return view("examinations.create");
    }

    public function store(Request $request) {
        $data = $request->all();
        MedicalExamination::create($data);
        return redirect("/examinations");
    }

    public function edit($id) {
        $item = MedicalExamination::find($id);
        return view("examinations.edit")->with(["item" => $item]);
    }

    public function update(Request $request) {
        $item = MedicalExamination::find($request->id);

        $data = $request->all();
    
        $item->fill($data)->save();

        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function destroy($id) {
        MedicalExamination::find($id)->delete();
        return redirect()->back();
    }
}
