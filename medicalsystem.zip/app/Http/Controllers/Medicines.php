<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Medicine;

class Medicines extends Controller
{
    public function index() {
        $data = Medicine::all();
        return view("medicines.index")->with(["data" => $data]);
    }

    public function create() {
        return view("medicines.create");
    }

    public function store(Request $request) {
        $data = $request->all();
        Medicine::create($data);
        return redirect("/medicines");
    }

    public function edit($id) {
        $item = Medicine::find($id);
        return view("medicines.edit")->with(["item" => $item]);
    }

    public function update(Request $request) {
        $item = Medicine::find($request->id);

        $data = $request->all();
    
        $item->fill($data)->save();

        return redirect()->back()->withSuccess(__('lang.changes_saved'));
    }

    public function destroy($id) {
        Medicine::find($id)->delete();
        return redirect()->back();
    }
}
